# schema.py
# ---------------------------------------------------------------------------
# Pydantic models used to validate the structured JSON returned by the LLM.
# Any change here must be mirrored in prompt.py (JSON template) so the LLM
# returns matching keys, and in app.py if you want to display the new field.
# ---------------------------------------------------------------------------

from pydantic import BaseModel
from typing import List, Optional


class MandatorySkill(BaseModel):
    """Represents a skill that is required for the project."""
    skill: str                              # e.g. "Python", "AWS"
    category: str                           # human-readable label: Programming, AI/ML, Cloud, etc.
    min_experience_years: Optional[float]   # minimum years of experience; null if not stated


class OptionalSkill(BaseModel):
    """Represents a nice-to-have skill for the project."""
    skill: str                              # e.g. "Docker", "GraphQL"
    category: str                           # human-readable label: Programming, AI/ML, Cloud, etc.


class ProjectExtraction(BaseModel):
    """
    Top-level schema for the extracted project metadata.
    Every field that cannot be reliably inferred should be null.
    """
    project_description: str                            # brief summary of the project
    mandatory_skills: List[MandatorySkill]               # skills explicitly required
    optional_skills: List[OptionalSkill]                 # skills listed as optional / nice-to-have
    domain: List[str]                                    # business domains (e.g. "Finance", "Healthcare")
    minimum_overall_experience_years: Optional[float]    # overall experience asked for
    required_bandwidth_percentage: Optional[int]         # e.g. 50 means 50 % allocation
    project_criticality: Optional[str]                   # HIGH / MEDIUM / LOW / null
    project_duration_months: Optional[int] = None        # estimated project duration in months
    confidence_notes: List[str]                          # notes on extraction confidence / caveats