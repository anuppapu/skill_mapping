# llm_client.py
# ---------------------------------------------------------------------------
# Handles communication with the LLM endpoint.
# 1. Builds the prompt using the template from prompt.py.
# 2. Sends the request and validates the JSON response against schema.py.
# ---------------------------------------------------------------------------

import json
import requests
from prompt import EXTRACTION_PROMPT
from schema import ProjectExtraction


def extract_project_metadata(text: str) -> dict:
    """
    Send raw project-requirement text to the LLM and return validated
    structured metadata as a plain dict.

    Returns a dict with an 'error' key when extraction or validation fails,
    so the caller can display a user-friendly message.
    """

    # --- 1. Build the prompt ------------------------------------------------
    # .format() replaces {text} with the user input; literal braces in the
    # template are already doubled {{ }} to avoid KeyError.
    prompt = EXTRACTION_PROMPT.format(text=text)
    endpoint_url = "https://api.your-llm-provider.com/v1/chat/completions"  # Replace with actual endpoint
    # --- 2. Authenticate ----------------------------------------------------
    api_key = "XXX"
    if not api_key:
        return {
            "error": "Invalid Token",
            "details": "check credentials",
            "raw_output": ""
        }

    # --- 3. Call the LLM endpoint -------------------------------------------
    headers = {
        "Content-Type": "application/json",
        "applicationType": "Replace_Accordingly",
        "Authorization": f"Bearer {api_key}"
    }
    data = {
        "messages": [{"role": "user", "content": prompt}],
        "model": "gpt-5.2",
        "max_tokens": 5000,
    }

    response = requests.post(endpoint_url, json=data, headers=headers, timeout=300)

    # --- 4. Handle HTTP-level errors ----------------------------------------
    if response.status_code == 200:
        raw = response.json()["choices"][0]["message"]["content"].strip()
    else:
        raise Exception(f"Error Generating Answer (HTTP {response.status_code}): {response.text}")

    # --- 5. Parse & validate the LLM output against the Pydantic schema -----
    try:
        parsed = json.loads(raw)                 # raw JSON string → dict
        validated = ProjectExtraction(**parsed)   # validate with Pydantic
        return validated.dict()                   # return plain dict for Streamlit
    except json.JSONDecodeError as e:
        # LLM returned something that is not valid JSON
        return {
            "error": "JSON parsing failed",
            "details": f"JSONDecodeError: {e}",
            "raw_output": raw
        }
    except Exception as e:
        # Pydantic validation or any other unexpected error
        return {
            "error": "Extraction failed",
            "details": str(e),
            "raw_output": raw
        }